package com.littleenglish.app

import android.app.Activity
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import android.content.Context
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var root: LinearLayout
    private val prefs by lazy { getSharedPreferences("little_english", Context.MODE_PRIVATE) }
    private var stars = 0
    private var quizIndex = 0
    private var quizScore = 0
    private var selected = -1
    private var answered = false

    private val navy = Color.rgb(31, 67, 119)
    private val blue = Color.rgb(55, 112, 205)
    private val pale = Color.rgb(237, 245, 255)
    private val ink = Color.rgb(38, 51, 72)
    private val words = listOf(
        Triple("Apple", "تفاحة", "🍎"), Triple("Banana", "موزة", "🍌"),
        Triple("Cat", "قطة", "🐱"), Triple("Dog", "كلب", "🐶"),
        Triple("Book", "كتاب", "📚"), Triple("Sun", "شمس", "☀️"),
        Triple("House", "منزل", "🏠"), Triple("Water", "ماء", "💧"),
        Triple("Bird", "طائر", "🐦"), Triple("Flower", "زهرة", "🌸")
    )
    private data class Q(val prompt: String, val options: List<String>, val correct: Int)
    private val questions = listOf(
        Q("ما معنى Apple؟ 🍎", listOf("تفاحة", "موزة", "برتقالة"), 0),
        Q("كيف نقول قطة بالإنجليزية؟ 🐱", listOf("Dog", "Cat", "Bird"), 1),
        Q("ما معنى School؟ 🏫", listOf("منزل", "مدرسة", "حديقة"), 1),
        Q("ما معنى Water؟ 💧", listOf("ماء", "شمس", "كتاب"), 0),
        Q("كيف نقول كلب بالإنجليزية؟ 🐶", listOf("Cat", "Bird", "Dog"), 2)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        stars = prefs.getInt("stars", 0)
        tts = TextToSpeech(this, this)
        buildShell()
        showHome()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts.language = Locale.UK
    }

    private fun buildShell() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(250, 252, 255))
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 18, 22, 18)
            setBackgroundColor(navy)
        }
        header.addView(label("🌈 Little English", 25, Color.WHITE, true))
        header.addView(label("هيا نتعلم الإنجليزية ونلعب!", 16, Color.WHITE))
        root.addView(header)
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(6, 8, 6, 8)
            setBackgroundColor(Color.WHITE)
        }
        listOf("الرئيسية" to "home", "الكلمات" to "words", "المحادثة" to "talk", "اختبار" to "quiz", "إنجازاتي" to "progress").forEach { (title, page) ->
            val b = Button(this).apply {
                text = title
                textSize = 11f
                isAllCaps = false
                setPadding(2, 4, 2, 4)
                setOnClickListener { when(page) {
                    "home" -> showHome()
                    "words" -> showWords()
                    "talk" -> showTalk()
                    "quiz" -> startQuiz()
                    else -> showProgress()
                } }
            }
            nav.addView(b, LinearLayout.LayoutParams(0, 48, 1f))
        }
        root.addView(nav)
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 12, 18, 28)
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        contentContainer = content
    }
    private lateinit var contentContainer: LinearLayout

    private fun label(text: String, size: Int, color: Int = ink, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(8, 8, 8, 8)
        }

    private fun heading(text: String) {
        contentContainer.addView(label(text, 22, navy, true))
    }

    private fun card(view: View) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 12, 12, 12)
            setBackgroundColor(Color.WHITE)
            elevation = 3f
        }
        box.addView(view)
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.setMargins(2, 8, 2, 8)
        contentContainer.addView(box, lp)
    }

    private fun action(text: String, onClick: () -> Unit) {
        val b = Button(this).apply {
            this.text = text
            isAllCaps = false
            textSize = 15f
            setTextColor(Color.WHITE)
            setBackgroundColor(blue)
            setOnClickListener { onClick() }
        }
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.setMargins(0, 7, 0, 7)
        contentContainer.addView(b, lp)
    }

    private fun resetContent() { contentContainer.removeAllViews() }

    private fun showHome() {
        resetContent()
        heading("مرحبًا يا بطل! ⭐")
        card(label("تعلم الإنجليزية بالصور والألعاب والمحادثات.\nابدأ بخطوة صغيرة كل يوم!", 18, ink, true))
        card(label("🍎     🐱     🏠     🌞\nصور وكلمات ممتعة", 26, blue, true))
        action("📚 ابدأ تعلم الكلمات") { showWords() }
        action("💬 تدرب على المحادثة") { showTalk() }
        action("🎮 اختبر معلوماتك") { startQuiz() }
        card(label("نجومك حتى الآن: ⭐ $stars", 18, navy, true))
    }

    private fun showWords() {
        resetContent()
        heading("📚 الكلمات المصوّرة")
        contentContainer.addView(label("اضغط زر النطق لسماع الكلمة بالإنجليزية.", 14, ink))
        words.forEach { (en, ar, emoji) ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(8, 6, 8, 6)
            }
            row.addView(label(emoji, 34, blue, true), LinearLayout.LayoutParams(64, -2))
            val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            texts.addView(label(en, 19, navy, true))
            texts.addView(label(ar, 16, ink))
            row.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
            val speak = Button(this).apply {
                text = "🔊"
                setOnClickListener { speak(en) }
            }
            row.addView(speak)
            card(row)
        }
    }

    private fun showTalk() {
        resetContent()
        heading("💬 محادثة التعارف")
        card(label("👧 Sara: Hello!\nمرحبًا!\n\n👦 Ali: What is your name?\nما اسمك؟\n\n👧 Sara: My name is Sara.\nاسمي سارة.\n\n👦 Ali: Nice to meet you!\nسعيد بلقائك!", 18, ink))
        action("🔊 استمع إلى المحادثة") {
            speak("Hello. What is your name? My name is Sara. Nice to meet you.")
        }
        action("تدرب على جملة: What is your name?") {
            speak("What is your name?")
        }
    }

    private fun startQuiz() {
        quizIndex = 0; quizScore = 0; selected = -1; answered = false
        showQuestion()
    }

    private fun showQuestion() {
        resetContent()
        heading("🏆 الاختبار الممتع")
        if (quizIndex >= questions.size) {
            stars += quizScore
            prefs.edit().putInt("stars", stars).apply()
            card(label("أحسنت! نتيجتك $quizScore من ${questions.size}\n⭐ نجومك الآن: $stars", 22, navy, true))
            action("أعد الاختبار") { startQuiz() }
            action("العودة للرئيسية") { showHome() }
            return
        }
        val q = questions[quizIndex]
        card(label("السؤال ${quizIndex + 1} من ${questions.size}\n${q.prompt}", 20, navy, true))
        q.options.forEachIndexed { i, option ->
            action(option) { if (!answered) { selected = i; answered = true
                if (selected == q.correct) quizScore++
                showQuestionFeedback(q)
            } }
        }
    }

    private fun showQuestionFeedback(q: Q) {
        resetContent()
        heading("🏆 السؤال ${quizIndex + 1}")
        card(label(q.prompt, 20, navy, true))
        card(label(if (selected == q.correct) "إجابة صحيحة! أحسنت ⭐" else "الإجابة الصحيحة: ${q.options[q.correct]}", 18,
            if (selected == q.correct) Color.rgb(20, 130, 75) else Color.rgb(180, 70, 55), true))
        action("السؤال التالي") { quizIndex++; selected = -1; answered = false; showQuestion() }
    }

    private fun showProgress() {
        resetContent()
        heading("🏅 إنجازاتي")
        card(label("جمعت حتى الآن:\n⭐ $stars نجمة", 24, navy, true))
        card(label("استمر في التعلم، فأنت تتقدم كل يوم!", 17, ink))
        action("تابع التعلم") { showWords() }
    }

    private fun speak(text: String) {
        if (::tts.isInitialized) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "little-english")
    }

    override fun onDestroy() {
        if (::tts.isInitialized) { tts.stop(); tts.shutdown() }
        super.onDestroy()
    }
}
